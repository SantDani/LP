#pragma once
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

using namespace std;

template <class T>
class TreeRB {
public:

	TreeRB() { m_left = NULL; m_right = NULL; m_father = NULL; m_data = NULL;  m_color = RED; };
	TreeRB(string nomFitxer);
	TreeRB(const TreeRB<T>& t);
	void setVal(const T& val) {m_data = val; };
	~TreeRB();
	bool isLeave() const { return ((m_left == NULL) && (m_right == NULL)); }
	bool isEmpty() const { return (m_data == NULL);}
	TreeRB<T>* getRight(){return m_right;}
	TreeRB<T>* getLeft() { return m_left; }
	T& getData() { return (*m_data); }
	bool cerca(const T& val, TreeRB<T>*& valTrobat);
	TreeRB<T>* oncle();
	bool esFillDret();
	bool esFillEsq();
	friend std::ostream& operator<<(std::ostream& out, const TreeRB<T>& t)
	{
		t.coutArbreRec(0, out);
		return out;
	};
	
	void insert(T& val);

private:
	enum COLOR { RED, BLACK };
	TreeRB<T>* m_left;
	TreeRB<T>* m_right;
	TreeRB<T>* m_father;
	T* m_data;
	COLOR m_color;

	void arreglaREDRED(TreeRB<T>* nouNode);
	void TreeRBRec(ifstream& fitxerNodes, int h, TreeRB<T>* father);
	std::ostream& coutArbreRec(int n, std::ostream& out) const;
	void rota(TreeRB<T>* nouNode, TreeRB<T>* pPare, TreeRB<T>* pAvi);
	void swapColor(TreeRB<T>* pNod1, TreeRB<T>* pNod2);
	void rotaEsq(TreeRB<T>* pNode);
	void rotaDreta(TreeRB<T>* pNode);
	void swapRootContents( TreeRB<T>* &pOldRoot, TreeRB<T>* &pNewRoot);
};


template<class T>

template<class T>
TreeRB<T>::TreeRB(const TreeRB<T>& t)
{
	m_color = t.m_color;

	if (t.m_left != NULL)
	{
		m_left = new(TreeRB<T>);
		m_left = t.m_left;
	}
	else
	{
		m_left = NULL;
	}

	if (t.m_right != NULL)
	{
		m_right = new(TreeRB<T>);
		m_right = t.m_right;
	}
	else
	{
		m_right = NULL;
	}
	//m_father: here m_father must be NULL
	//we are creating a TreeRB, if it has to be connected with another one you will use setRight o r left.
	m_father = NULL;

	if (t.m_data != NULL)
	{
		m_data = new(T);
		m_data = t.m_data;
	}
	else
	{
		m_data = NULL;
	}
}

template<class T>
bool TreeRB<T>::esFillDret()
{
	//FER CODI
}

template<class T>
bool TreeRB<T>::esFillEsq()
{
	//FER CODI
}

template<class T>
TreeRB<T>* TreeRB<T>::oncle()
{
	//FER CODI
}

template<class T>
void TreeRB<T>::swapColor(TreeRB<T>* pNod1, TreeRB<T>* pNod2)
{
	//FER CODI
}

template<class T>
void TreeRB<T>::swapRootContents( TreeRB<T>* &pOldRoot, TreeRB<T>* &pNewRoot){
	//FER CODI
}

template<class T>
void TreeRB<T>::rotaEsq(TreeRB<T>* pNodAct)
{
	//El pNode es avi que pasara a ser fill esquerre del seu filldret
	//El fill dret passara a ser el pare
	//El fill esquerre del fill dret passara a ser el fill dret de l'avi (pNode)
	
	//Com avi pot ser l'arrel no movem node de lloc
	//FER CODI
}

template<class T>
void TreeRB<T>::rotaDreta(TreeRB<T>* pNodAct)
{
	//El pNodAct es avi o pare que pasara a ser fill dret del seu fillesquerre
	//El fill esquerre de pNodAct passara a ser pare
	//El fill dret del fill esquerre de pNodAct (si no es NULL) passara a ser el fill esquerre de l'avi (pNodAct)

	//Com avi pot ser l'arrel no movem node de lloc
	//intercanviem node pNodAct amb pFE i modifiquem els seus fills i pares de la seguent manera

	//FER CODI
}

template<class T>
void TreeRB<T>::rota(TreeRB<T>* nouNode, TreeRB<T>* pPare, TreeRB<T>* pAvi)
{
	//FER CODI
}

template<class T>
void TreeRB<T>::arreglaREDRED(TreeRB<T>* nouNode)
{
	//FER CODI
}

template<class T>
void TreeRB<T>::insert(T& val)
{
	if (m_data == NULL)
	{//Arbre buit
		m_data = new T;
		(*m_data) = val;
		m_color = BLACK;
	}
	else
	{
		TreeRB<T>* ptAux=nullptr;
		bool trobat = cerca(val, ptAux);
		if (!trobat)
		{//Si trobem valor no fem res; si no el trobem

			//Creem un node RED amb valor val fill de ptAux
			TreeRB<T>* nouNode = new TreeRB<T>;
			nouNode->m_data = new T;
			(*nouNode->m_data) = val;
			nouNode->m_father = ptAux;

			if (val < (*ptAux->m_data))
			{//El nou valor sera fillEsq de ptAux
				ptAux->m_left= nouNode;
			}
			else
			{//El nou valor sera fillDret de ptAux
				ptAux->m_right= nouNode;
			}

			arreglaREDRED(nouNode);
		}
	}
}

/////////////////////////////////////////////////////////////////////////////
// TreeRB(nomFitxer):                                                        //
//                 constructor que obre fitxer i crida a metode privat     //
// TreeRBRec(ifstream& fitxerNodes, int h, TreeRB<T>* father)              //
//            metode privat que llegeix arbre de forma recursiva           //
//Lectura d'un fitxer a on tindrem                                         //
//alcada                                                                   //
//estat: 0 o 1 segons sigui buit o amb informacio al costat dada           //
//Esta en preordre Preordre(FillEsq) Arrel Preordre(FillDret)                //
/////////////////////////////////////////////////////////////////////////////
template<class T>
TreeRB<T>::TreeRB(string nomFitxer)
{
	ifstream fitxerNodes;

	fitxerNodes.open(nomFitxer.c_str());
	if (fitxerNodes.is_open())
	{
		//Llegim al�ada arbre binari
		int h;
		fitxerNodes >> h;
		if (!fitxerNodes.eof())
		{
			int estat;
			fitxerNodes >> estat;
			if (estat == 1)
			{
				if (fitxerNodes.is_open())	TreeRBRec(fitxerNodes, h, NULL);
			}
		}
		fitxerNodes.close();
	}
}

template<class T>
void TreeRB<T>::TreeRBRec(ifstream& fitxerNodes, int h, TreeRB<T>* father)
{
	m_father = father;
	m_data = new(T);
	fitxerNodes >> (*m_data);
	if (h > 0)
	{
		int estat;
		if (!fitxerNodes.eof())
		{			
			fitxerNodes >> estat;
			if (!fitxerNodes.eof())
			{
				if (estat == 1)
				{
					m_left = new(TreeRB<T>);
					m_left->TreeRBRec(fitxerNodes, h - 1, this);
				}
			}
		}
		if (!fitxerNodes.eof())
		{
			fitxerNodes >> estat;
			if (!fitxerNodes.eof())
			{
				if (estat == 1)
				{
					m_right = new(TreeRB<T>);
					m_right->TreeRBRec(fitxerNodes, h - 1, this);
				}
			}
		}
	}
}


template<class T>
TreeRB<T>::~TreeRB()
{
	if (m_right != NULL)
	{
		delete m_right;
	}

	if (m_left != NULL)
	{
		delete m_left;
	}

	if (m_data != NULL)
	{
		delete m_data;
	}

	m_father = NULL;
}

//Suposem l'arbre ordenat amb valors menors a arrel a esquerra i valors majors a dreta
template<class T>
bool TreeRB<T>::cerca(const T& val, TreeRB<T>*& valTrobat)
{
	if (m_data != NULL)
	{
		if (val == (*m_data))
		{
			valTrobat = this;
			return true;
		}
		else
			if (val < (*m_data))
			{
				if (m_left != NULL)
				{
					return m_left->cerca(val, valTrobat);
				}
				else
					valTrobat = this;
			}
			else
			{
				if (m_right != NULL)
				{
					return (m_right->cerca(val, valTrobat));
				}
				else
					valTrobat = this;
			}		
	}
	return false;
}

/////////////////////////////////////////////////////////////////////////////
// coutArbreRec():                                                         //
//         Metode privat cridat per operator<<                             //
//                       que escriu arbre per pantalla de forma recursiva  //
// |--arrel                                                                //
// |---->FillDret1                                                         //
// |------>FillDret2                                                       //
// |------>FillEsquerre2                                                   //
// |---->FillEsquerre1                                                     //
//alcada                                                                   //
//estat: 0 o 1 segons sigui buit o amb informacio al costat dada           //
//Esta en inordre Inordre(FillEsq) Arrel Inordre(FillDret)                 //
/////////////////////////////////////////////////////////////////////////////
template<class T>
std::ostream& TreeRB<T>::coutArbreRec(int n, std::ostream& out) const
{
	if (isEmpty())
	{//Pintem arbre buit
		for (int i = 0; i < n; i++)
		{
			out << "|--";
		}
		out << "-->BUIT" << endl;
	}
	else
	{
		for (int i = 0; i < n; i++)
		{
			out << "|--";
		}
		out << "|-->";
		if (m_color == RED)
			out << "RED,";
		else
			out << "BLACK,"; 
		out << (*m_data) << endl;
		if (!isLeave())
		{
			if (m_left != NULL)
			{
				m_left->coutArbreRec(n + 1,out);
			}
			else
			{
				for (int i = 0; i < n + 1; i++)
				{
					out << "|--";
				}
				out << "|-->BUIT" << endl;
			}
			if (m_right != NULL)
			{
				m_right->coutArbreRec(n + 1,out);
			}
			else
			{
				for (int i = 0; i < n + 1; i++)
				{
					out << "|--";
				}
				out << "|-->BUIT" << endl;
			}
		}
	}
	return out;
}
