#pragma once

class Hora
{

};
