#include "Punt.h"

Punt::Punt()
{

}

Punt::~Punt()
{

}

Punt::Punt(const Punt& pt)
{
    m_x = pt.m_x;
    m_y = pt.m_y;
}

