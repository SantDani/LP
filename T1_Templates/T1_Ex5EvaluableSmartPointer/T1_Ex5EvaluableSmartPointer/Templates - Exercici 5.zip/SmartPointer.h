#pragma once
#include <iostream>
using namespace std;

template <class T>
class SmartPointer
{
public:
private:

};

