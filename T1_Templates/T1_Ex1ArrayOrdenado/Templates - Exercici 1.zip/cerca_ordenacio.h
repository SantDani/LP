#pragma once

template <class T>
void ordena(T vector[], int nElements)
{
}


template <class T>
bool cercaBinaria(T vector[], const T& valor, int nElements)
{
}