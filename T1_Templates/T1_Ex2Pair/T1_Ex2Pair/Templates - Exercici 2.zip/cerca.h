#pragma once
#include <utility>
using namespace std;

template <class TClau, class TValor>
bool cercaBinaria(pair<TClau, TValor> vector[], const TClau& clau, int nElements, TValor& valor)
{

}